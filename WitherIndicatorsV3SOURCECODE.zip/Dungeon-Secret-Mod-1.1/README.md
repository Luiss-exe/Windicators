# Dungeon-Secret-Mod V1.0

Why is this useful?
For those who haven't memorized secrets, trying to find secrets takes forever, especially when you have to spend a ton of time searching through DSG channels for the right room. This mod makes it easy as you can immediately see where a secret is.

Is this bannable?
No. Because our mod is made by us viewing and adding where each secret is for each room no kinds of esp or anything is used. You may notice that bat spawns are not where our mod says they are. That's because, if the bat is already moving around we only have the spawn location marked. 

Discord - Vixed#8832

Hotkeys:
(Configurable in Controls Menu)

P - Opens Secret Waypoints configuration GUI
O - Opens images of secret locations
Commands:
/room - Tells you in chat what room you are standing in.
/room help - Displays this message in chat.
/room waypoints - Opens Secret Waypoints config GUI, alternatively can be opened with hotkey
/room move <x> <y> - Moves the GUI room name text to a coordinate. and are numbers between 0 and 100. (Default is 50 for <x> and 5 for <y>)
/room toggle [argument] - Run "/room toggle help" for full list of toggles.
/room set <gui | dsg | sbp> - Configure whether the hotkey opens the selector GUI or directly goes to DSG/SBP.
/room discord - Opens the Discord invite for this mod in your browser.
/room open - Opens the gui for opening either DSG or SBP.
/room dsg - Directly opens DSG in the Discord client.
/room sbp - Directly opens the SBP secrets (if you have the mod installed).
